def print_func(par):
   print ('Hello,' + par)
   return


if __name__ == '__main__':
   print('Hello AQF')